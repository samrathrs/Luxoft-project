import model.{AggregationSemigroup, OutputDataSemigroup}

/** Provide implicits for Aggregation and OutputData */
package object implicits extends AggregationSemigroup with OutputDataSemigroup
